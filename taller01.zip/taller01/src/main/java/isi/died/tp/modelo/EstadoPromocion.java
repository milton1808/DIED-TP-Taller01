/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package isi.died.tp.modelo;

/**
 *
 * @author mdominguez
 */
public enum EstadoPromocion {

    ACCESO_TEMPRANO,LANZAMIENTO,OFERTA,REGULAR
    
}
